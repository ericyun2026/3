# 音乐

我喜欢 Ed Sheeran、Taylor Swift 和 Coldplay。这里会记录专辑、歌单与现场。

## 正在循环

内容准备中。
