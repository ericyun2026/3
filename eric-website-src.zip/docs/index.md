---
hide:
  - navigation
  - toc
---

<section class="hero">
  <p class="eyebrow">ERIC'S CORNER OF THE INTERNET</p>
  <h1>你好，我是 Eric。</h1>
  <p class="hero-copy">这里收藏我读过的书、喜欢的电影与音乐，也记录值得关注的创作者和偶尔冒出来的想法。</p>
  <div class="hero-actions"><a class="primary-button" href="books/">开始逛逛</a><a class="text-button" href="about/">认识我 →</a></div>
</section>

<div class="section-heading"><p class="eyebrow">EXPLORE</p><h2>我的收藏与表达</h2></div>

<div class="category-grid" markdown>

[:material-book-open-page-variant: **书籍**<br><span>读过、想读，以及留在书页里的句子。</span>](books/){ .category-card }

[:material-movie-open: **电影**<br><span>光影、故事和看完之后的余韵。</span>](movies/){ .category-card }

[:material-music: **音乐**<br><span>Ed Sheeran、Taylor Swift、Coldplay 与更多声音。</span>](music/){ .category-card }

[:material-controller-classic: **游戏**<br><span>《星露谷物语》、独立游戏与虚拟世界。</span>](games/){ .category-card }

[:material-robot-outline: **AI**<br><span>理解人工智能，也记录我的探索与实践。</span>](ai/){ .category-card }

[:material-laptop: **科技**<br><span>产品、编程，以及改变生活的新技术。</span>](technology/){ .category-card }

[:material-television-play: **B站 UP 主**<br><span>值得关注的创作者与宝藏视频。</span>](creators/){ .category-card }

[:material-fountain-pen-tip: **随笔**<br><span>关于科技、学习、生活和那些突然想到的事。</span>](essays/){ .category-card }

[:material-account-circle: **关于我**<br><span>Eric，喜欢科技、音乐，也喜欢创造新东西。</span>](about/){ .category-card }

</div>
