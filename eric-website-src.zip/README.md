# Eric 的个人网站

你好，我是 Eric。这是我的个人网站：书籍、电影、音乐、游戏、AI、科技、B站 UP 主、随笔与关于我。

- 生成工具：[MkDocs](https://www.mkdocs.org)
- 主题：[Material for MkDocs](https://squidfunk.github.io/mkdocs-material/)
- 发布方式：GitHub Pages（推送 `main` 分支后由 GitHub Actions 自动构建部署）

## 本地预览

```bash
pip install -r requirements.txt
mkdocs serve
```

浏览器打开 <http://127.0.0.1:8000> 即可预览。

## 发布到 GitHub Pages

1. 在 GitHub 新建仓库，仓库名设为 `ericyun2026.github.io`（改成你自己的 GitHub 用户名）。
2. 把本目录所有文件推送到该仓库的 `main` 分支。
3. 在仓库 Settings → Pages 中把 Source 设为 **GitHub Actions**（只需设置一次）。
4. 之后每次推送，Actions 会自动 `mkdocs build` 并部署，稍等片刻即可访问
   `https://ericyun2026.github.io`。

> 站点地址、作者等信息在 `mkdocs.yml` 顶部修改。

## 添加内容

- 所有页面源文件在 `docs/` 下，使用 Markdown 编写。
- 想新增栏目/文章时，在 `mkdocs.yml` 的 `nav` 里登记即可（顶部 Tab 会自动出现）。
- 每篇文档可用 `---` 开头添加 `title` / `description` / `tags` 元信息。